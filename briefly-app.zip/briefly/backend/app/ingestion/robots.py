"""robots.txt gate.

Every outbound fetch passes through :func:`is_allowed`. Failure to read a
robots file is treated as *disallowed* for anything but the robots file itself:
if we cannot establish permission, we do not fetch.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from urllib.parse import urlsplit
from urllib.robotparser import RobotFileParser

import httpx

from app.config import get_settings

_CACHE_TTL_SECONDS = 3600


@dataclass
class _Entry:
    parser: RobotFileParser | None
    fetched_at: float
    reachable: bool


class RobotsCache:
    def __init__(self, ttl: int = _CACHE_TTL_SECONDS) -> None:
        self._cache: dict[str, _Entry] = {}
        self.ttl = ttl

    def _origin(self, url: str) -> str:
        parts = urlsplit(url)
        return f"{parts.scheme}://{parts.netloc}"

    def _load(self, origin: str, client: httpx.Client | None = None) -> _Entry:
        settings = get_settings()
        robots_url = f"{origin}/robots.txt"
        owns_client = client is None
        client = client or httpx.Client(
            timeout=settings.http_timeout_seconds,
            headers={"User-Agent": settings.user_agent},
            follow_redirects=True,
        )
        try:
            resp = client.get(robots_url)
            parser = RobotFileParser()
            if resp.status_code == 200:
                parser.parse(resp.text.splitlines())
                return _Entry(parser, time.time(), True)
            if resp.status_code in (401, 403):
                # Explicitly withheld: treat the whole origin as off limits.
                parser.disallow_all = True
                return _Entry(parser, time.time(), True)
            # 404 / 410 and friends: no robots file means no restrictions.
            parser.allow_all = True
            return _Entry(parser, time.time(), True)
        except Exception:
            return _Entry(None, time.time(), False)
        finally:
            if owns_client:
                client.close()

    def get(self, url: str, client: httpx.Client | None = None) -> _Entry:
        origin = self._origin(url)
        entry = self._cache.get(origin)
        if entry and (time.time() - entry.fetched_at) < self.ttl:
            return entry
        entry = self._load(origin, client)
        self._cache[origin] = entry
        return entry

    def is_allowed(self, url: str, *, client: httpx.Client | None = None) -> bool:
        settings = get_settings()
        entry = self.get(url, client)
        if entry.parser is None:
            # Could not read robots.txt at all — do not fetch.
            return False
        agent = settings.user_agent.split("/")[0] or "*"
        # One question, asked once. The parser already falls back to the "*"
        # rules when a site has none for us by name; asking "*" separately and
        # accepting either answer would let a general welcome override a
        # refusal addressed to this bot specifically.
        return entry.parser.can_fetch(agent, url)

    def crawl_delay(self, url: str) -> float | None:
        entry = self.get(url)
        if entry.parser is None:
            return None
        agent = get_settings().user_agent.split("/")[0] or "*"
        try:
            delay = entry.parser.crawl_delay(agent) or entry.parser.crawl_delay("*")
        except Exception:
            return None
        return float(delay) if delay else None

    def clear(self) -> None:
        self._cache.clear()


_ROBOTS = RobotsCache()


def is_allowed(url: str, *, client: httpx.Client | None = None) -> bool:
    if not get_settings().respect_robots:  # pragma: no cover - pinned True by config
        return True
    return _ROBOTS.is_allowed(url, client=client)


def crawl_delay(url: str) -> float | None:
    return _ROBOTS.crawl_delay(url)


def clear_cache() -> None:
    _ROBOTS.clear()
